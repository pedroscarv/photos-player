@echo off
title PHOTOS PLAYER
set "PASTA=%~1"
if not "%PASTA%"=="" goto :ok
set "PASTA=%CD%"
:ok
echo.
echo PHOTOS PLAYER - Gerando album em:
echo %PASTA%
echo.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0gerar_album.ps1" -Pasta "%PASTA%"
if errorlevel 1 goto :erro
start "" "%PASTA%\Album.html"
exit /b 0
:erro
echo.
echo Nao foi possivel gerar o album.
echo Verifique se a pasta contem imagens.
echo.
pause
exit /b 1
