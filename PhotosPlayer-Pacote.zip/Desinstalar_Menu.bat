@echo off
chcp 65001 >nul
echo Removendo o menu do Photos Player...
reg delete "HKCU\Software\Classes\Directory\shell\PhotosPlayer" /f >nul 2>&1
reg delete "HKCU\Software\Classes\Directory\Background\shell\PhotosPlayer" /f >nul 2>&1
echo Menu removido.
pause
