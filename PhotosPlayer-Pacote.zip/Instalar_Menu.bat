@echo off
chcp 65001 >nul
title Instalar menu - PHOTOS PLAYER
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Instalar_Menu.ps1"
echo.
pause
