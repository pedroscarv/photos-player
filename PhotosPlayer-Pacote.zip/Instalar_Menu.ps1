$ErrorActionPreference = 'Stop'

$base = Split-Path -Parent $MyInvocation.MyCommand.Path
$launcher = Join-Path $base 'Abrir_Photos_Player.cmd'
if (-not (Test-Path -LiteralPath $launcher)) { throw "Launcher nao encontrado: $launcher" }

$comando = 'cmd.exe /c ""' + $launcher + '" "%V""'
$rotulo = 'Abrir no Photos Player'

$locais = @(
  'HKCU:\Software\Classes\Directory\shell\PhotosPlayer',
  'HKCU:\Software\Classes\Directory\Background\shell\PhotosPlayer'
)

foreach ($local in $locais) {
  New-Item -Path $local -Force | Out-Null
  New-ItemProperty -Path $local -Name '(default)' -Value $rotulo -PropertyType String -Force | Out-Null
  New-ItemProperty -Path $local -Name 'MUIVerb' -Value $rotulo -PropertyType String -Force | Out-Null
  New-ItemProperty -Path $local -Name 'Icon' -Value "$env:SystemRoot\System32\shell32.dll,-16769" -PropertyType String -Force | Out-Null

  $cmdKey = Join-Path $local 'command'
  New-Item -Path $cmdKey -Force | Out-Null
  New-ItemProperty -Path $cmdKey -Name '(default)' -Value $comando -PropertyType String -Force | Out-Null
}

"Menu instalado: $rotulo"
"Comando: $comando"
""
"Feche e abra o Explorer (ou reinicie-o) se a opcao nao aparecer."
