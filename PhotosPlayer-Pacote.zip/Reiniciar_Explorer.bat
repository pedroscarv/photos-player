@echo off
echo Reiniciando o Explorer para atualizar o menu...
taskkill /f /im explorer.exe >nul 2>&1
start explorer.exe
echo Pronto.
