param(
  [string]$Pasta = (Get-Location).Path
)

$ErrorActionPreference = 'Stop'

$Pasta = $Pasta.Trim().TrimEnd('"', ' ')
$pasta = (Resolve-Path -LiteralPath $Pasta).Path
$nomePasta = (Get-Item -LiteralPath $pasta).Name

$extensoes = @('.png', '.jpg', '.jpeg', '.webp', '.gif', '.bmp')
$arquivos = Get-ChildItem -LiteralPath $pasta -File | Where-Object { $extensoes -contains $_.Extension.ToLowerInvariant() }

function Chave-Natural([string]$texto) {
  return [regex]::Replace($texto, '\d+', { param($m) '0' + $m.Value.PadLeft(12, '0') })
}

$arquivos = $arquivos | Sort-Object { Chave-Natural $_.Name }
$nomes = @($arquivos | ForEach-Object { $_.Name })

if ($nomes.Count -eq 0) {
  throw "Nenhuma imagem encontrada na pasta: $pasta"
}

$partesJson = @($nomes | ForEach-Object {
  $seguro = $_.Replace('\', '\\').Replace('"', '\"')
  '"' + $seguro + '"'
})
$jsonFotos = '[' + ($partesJson -join ',') + ']'
$jsonNome = $nomePasta | ConvertTo-Json -Compress

$template = @'
<!doctype html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Photos Player</title>
<style>
  :root { --bg:#000; --panel:#070707; --border:#262626; --text:#e6edf3; --muted:#8b949e; --accent:#2f81f7; }
  * { box-sizing:border-box; }
  html,body { margin:0; padding:0; height:100%; background:var(--bg); color:var(--text); overflow:hidden; font-family:"Segoe UI",Roboto,Arial,sans-serif; }
  body { display:flex; flex-direction:column; }
  header { flex:0 0 auto; display:flex; align-items:center; justify-content:center; gap:8px; padding:10px 16px; background:var(--panel); border-bottom:1px solid var(--border); }
  button { background:#21262d; color:var(--text); border:1px solid var(--border); border-radius:6px; padding:7px 12px; font:inherit; font-size:13px; cursor:pointer; }
  button:hover:not(:disabled) { background:#30363d; border-color:#8b949e; }
  button:disabled { opacity:.38; cursor:default; }
  button#btnAnterior { background:#79c0ff; border-color:#79c0ff; color:#0d1117; font-weight:600; }
  button#btnAnterior:hover:not(:disabled) { background:#a5d6ff; }
  button#btnProxima { background:var(--accent); border-color:var(--accent); color:#fff; }
  button#btnProxima:hover:not(:disabled) { background:#388bfd; }
  .contador { min-width:120px; text-align:center; font:700 15px Consolas,monospace; font-variant-numeric:tabular-nums; }
  .contador small { color:var(--muted); font-weight:400; }
  .banner { flex:0 0 auto; text-align:center; background:#ffe600; color:#101010; padding:13px 24px;
            font:700 clamp(14px,1.6vw,20px) Consolas,"Courier New",monospace; letter-spacing:.2px;
            border-bottom:2px solid #d1a800; box-shadow:0 4px 22px rgba(255,230,0,.22); }
  .marca { color:#6a1b9a; font-weight:700; letter-spacing:1px; }
  .pasta { color:#0b6623; }
  main { flex:1 1 auto; min-height:0; position:relative; display:flex; align-items:center; padding:12px 70px; overflow:hidden; user-select:none; }
  .dupla { flex:1 1 auto; height:100%; display:flex; gap:14px; }
  .lado { flex:1 1 0; min-width:0; display:flex; align-items:center; justify-content:center; padding:8px; border:1px solid #222; background:#050505; position:relative; }
  .lado img { max-width:100%; max-height:100%; object-fit:contain; background:#fff; box-shadow:0 6px 24px rgba(255,255,255,.1); }
  .lado .numero { position:absolute; left:8px; bottom:6px; font:12px Consolas,monospace; color:#ffe600; }
  .lado .fim { display:none; flex-direction:column; align-items:center; gap:8px; color:#ffe600; font-family:Consolas,monospace; }
  .lado .fim strong { font-size:44px; letter-spacing:8px; }
  .lado .fim span { font-size:13px; color:#888; }
  .lado .fim .credito { color:#ffe600; font-size:13px; letter-spacing:0; line-height:1.5; text-align:center; }
  .zona { position:absolute; top:0; bottom:0; width:64px; display:flex; align-items:center; justify-content:center; color:var(--muted); font-size:30px; cursor:pointer; opacity:.25; }
  .zona:hover { opacity:1; background:rgba(255,255,255,.04); }
  .zona.esq { left:0; } .zona.dir { right:0; }
  footer { flex:0 0 auto; display:flex; align-items:center; gap:14px; padding:8px 18px; background:var(--panel); border-top:1px solid var(--border); color:var(--muted); font-size:11px; }
  #progresso { flex:1; height:4px; border-radius:3px; background:#30363d; overflow:hidden; }
  #progresso > div { height:100%; width:0; background:var(--accent); transition:width .2s; }
  kbd { background:#21262d; border:1px solid var(--border); border-radius:4px; padding:1px 5px; font:inherit; color:var(--text); }
  @media (max-width:760px) { main { padding:8px 34px; } .zona { width:34px; } }
</style>
</head>
<body>

<header>
  <button id="btnInicio" title="In&iacute;cio (Home)">&#x23EE; In&iacute;cio</button>
  <button id="btnAnterior" title="Anterior (&larr;)">&#x25C0; Anterior</button>
  <div class="contador" aria-live="polite"><span id="atual">1-2</span> <small>/</small> <span id="total">0</span></div>
  <button id="btnProxima" title="Pr&oacute;xima (&rarr;)">Pr&oacute;xima &#x25B6;</button>
  <button id="btnFim" title="Fim (End)">Fim &#x23ED;</button>
</header>

<div class="banner"><span class="marca">PHOTOS PLAYER</span> : <span id="pasta" class="pasta"></span></div>

<main id="palco">
  <div class="zona esq" id="zonaEsq" title="Anterior">&lsaquo;</div>
  <div class="dupla">
    <div class="lado"><img id="slideA" alt="Foto esquerda"><span class="numero" id="numA"></span></div>
    <div class="lado"><img id="slideB" alt="Foto direita"><div class="fim" id="fim"><strong>FIM</strong><span class="credito">Produzido por:<br>OpenCode V: 2.3.2 e Pepeh</span></div><span class="numero" id="numB"></span></div>
  </div>
  <div class="zona dir" id="zonaDir" title="Pr&oacute;xima">&rsaquo;</div>
</main>

<footer>
  <div id="progresso"><div></div></div>
  <div><kbd>&larr;</kbd> <kbd>&rarr;</kbd> navegar &nbsp;&middot;&nbsp; <kbd>Home</kbd> <kbd>End</kbd> in&iacute;cio/fim &nbsp;&middot;&nbsp; clique nos lados</div>
</footer>

<script>
(function () {
  'use strict';
  var FOTOS = __FOTOS__;
  var NOME = __NOMEPASTA__;
  var TOTAL = FOTOS.length;
  var slideA = document.getElementById('slideA');
  var slideB = document.getElementById('slideB');
  var fim = document.getElementById('fim');
  var atual = 1;

  document.title = 'PHOTOS PLAYER : ' + NOME;
  document.getElementById('pasta').textContent = NOME;
  document.getElementById('total').textContent = TOTAL;

  function src(n) { return encodeURIComponent(FOTOS[n - 1]); }

  function irPara(n) {
    if (!TOTAL) return;
    n = parseInt(n, 10) || 1;
    if (n % 2 === 0) n -= 1;
    n = Math.max(1, Math.min(TOTAL, n));
    atual = n;
    var dir = n + 1;
    slideA.src = src(n);
    document.getElementById('numA').textContent = n + ' / ' + TOTAL;
    if (dir <= TOTAL) {
      slideB.style.display = '';
      fim.style.display = 'none';
      slideB.src = src(dir);
      document.getElementById('numB').textContent = dir + ' / ' + TOTAL;
    } else {
      slideB.removeAttribute('src');
      slideB.style.display = 'none';
      fim.style.display = 'flex';
      document.getElementById('numB').textContent = '';
    }
    document.getElementById('atual').textContent = n + '-' + Math.min(dir, TOTAL);
    document.querySelector('#progresso > div').style.width = (n / TOTAL * 100) + '%';
    document.getElementById('btnInicio').disabled = n === 1;
    document.getElementById('btnAnterior').disabled = n === 1;
    document.getElementById('btnProxima').disabled = n >= TOTAL;
    document.getElementById('btnFim').disabled = n >= TOTAL;
  }

  document.getElementById('btnInicio').addEventListener('click', function () { irPara(1); });
  document.getElementById('btnAnterior').addEventListener('click', function () { irPara(atual - 2); });
  document.getElementById('btnProxima').addEventListener('click', function () { irPara(atual + 2); });
  document.getElementById('btnFim').addEventListener('click', function () { irPara(TOTAL); });
  document.getElementById('zonaEsq').addEventListener('click', function () { irPara(atual - 2); });
  document.getElementById('zonaDir').addEventListener('click', function () { irPara(atual + 2); });

  document.addEventListener('keydown', function (e) {
    if (e.altKey || e.ctrlKey || e.metaKey) return;
    switch (e.key) {
      case 'ArrowRight': case 'PageDown': case ' ': irPara(atual + 2); break;
      case 'ArrowLeft': case 'PageUp': irPara(atual - 2); break;
      case 'Home': irPara(1); break;
      case 'End': irPara(TOTAL); break;
      default: return;
    }
    e.preventDefault();
  });

  var x = null;
  document.getElementById('palco').addEventListener('touchstart', function (e) { x = e.changedTouches[0].clientX; }, { passive:true });
  document.getElementById('palco').addEventListener('touchend', function (e) {
    if (x === null) return;
    var dx = e.changedTouches[0].clientX - x;
    if (Math.abs(dx) > 50) irPara(atual + (dx < 0 ? 2 : -2));
    x = null;
  }, { passive:true });

  irPara(1);
})();
</script>
</body>
</html>
'@

$html = $template.Replace('__FOTOS__', $jsonFotos).Replace('__NOMEPASTA__', $jsonNome)
$destino = Join-Path $pasta 'Album.html'
$utf8 = New-Object System.Text.UTF8Encoding($false)
[System.IO.File]::WriteAllText($destino, $html, $utf8)

"Album criado: $destino"
"Fotos encontradas: $($nomes.Count)"
"Pasta: $nomePasta"
